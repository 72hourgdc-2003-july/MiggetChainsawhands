If you are experiencing choppy music in Migget Chainsaw Hands, we suggest the following fix:

1. go to your Migget folder, and rename startup\sounds\musictest1.mp3 to something else.
2. copy musictest1.mp3 from this zip into startup\sounds\
3. play the origional mp3 in windows media player while playing the game. Or dont. you could listen    to Celine Dion or something. no, listen to Madness.
4. What are you still doing here? That fixed the problem didn't it?